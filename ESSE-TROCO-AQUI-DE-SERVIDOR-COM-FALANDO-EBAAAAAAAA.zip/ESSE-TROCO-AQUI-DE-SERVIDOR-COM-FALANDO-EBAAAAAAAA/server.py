from flask import Flask, render_template, request 

from flask_socketio import SocketIO, send, emit 

app = Flask(__name__) .
app.config['SECRET_KEY'] = 'segredo' # Define uma chave secreta usada pelo Flask para segurança (sessões, cookies, etc.)
socketio = SocketIO (app) # conecta o servidor Flask ao sistema de WebSocket.
usuarios = {} # Dicionário para guardar os usuários conectados.

 #Define a rota principal do servidor (quando acessamos "/")
@app.route('/') 
def chat(): # Função para abrir o arquivo index.html que está na pasta templates. Rota principal já abre o chat. 14
  return render_template('index.html')

#Evento disparado quando o usuário envia o nome do usuário.
@socketio.on('apelido')
def definir_apelido (apelido): #Função para guardar o apelido do usuário.
 usuarios[request.sid] = apelido #Guarda o apelido do usuário no dicionário usando o ID da sessão.
 send(f" {apelido} entrou no chat!", broadcast=True) # Envia uma mensagem para todos os usuários conectados.
 atualizar_lista() # Atualiza a lista de usuários conectados.
# Evento disparado quando o cliente envia uma mensagem

@socketio.on('mensagem')
def mensagem(msg):
    # Quando o cliente envia uma mensagem
    # Pega o apelido do usuário (ou "Anônimo" se não tiver)
    apelido = usuarios.get(request.sid, "Anônimo") 
    # Envia a mensagem para todos os usuários conectados
    send(f"[{apelido}]: {msg}", broadcast=True) 

# Evento disparado quando o cliente se desconecta
@socketio.on('disconnect')
def desconectado():
    # Quando o cliente sai
    apelido = usuarios.pop(request.sid, "Anônimo")
    send(f"{apelido} saiu do chat.", broadcast=True)
    atualizar_lista()

def atualizar_lista():
    # Atualiza a lista de usuários conectados em tempo real
    lista = list(usuarios.values())
    emit("usuarios", lista, broadcast=True)

if __name__ == '__main__':
    # Ponto de entrada do programa. Executa o servidor acessível pelo Replit.
    # Em publicação, o reloader/debug do Flask não deve ser usado. O parâmetro
    # allow_unsafe_werkzeug evita que o Flask-SocketIO encerre o processo ao
    # detectar o servidor Werkzeug fora do modo de desenvolvimento.
    socketio.run(
        app,
        host='0.0.0.0',
        port=5000,
        debug=False, # desativa o modo de desenvolvimento
        allow_unsafe_werkzeug=True
    )

# Werkzeug é uma biblioteca Python usada pelo Flask para receber e responder requisições HTTP.
# allow_unsafe_werkzeug=True permite que o servidor Werkzeug seja usado mesmo na publicação.
