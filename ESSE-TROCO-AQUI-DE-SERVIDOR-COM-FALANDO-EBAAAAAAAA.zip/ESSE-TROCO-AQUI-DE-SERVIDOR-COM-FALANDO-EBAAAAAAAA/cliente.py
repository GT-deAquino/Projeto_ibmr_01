import socket
import threading

HOST = '127.0.0.1'
PORT = 5000

def ouvir_servidor(sock):
    while True:
        data = sock.recv(1024)
        if not data:
            break
        print("\nMensagem recebida: ", data.decode('utf-8'))

client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client_socket.connect((HOST, PORT))

# Recebe pedido de apelido
mensagem_inicial = client_socket.recv(1024).decode('utf-8')
apelido = input(mensagem_inicial)
client_socket.sendall(apelido.encode('utf-8'))
print(f"Conectado ao servidor como {apelido}!")

# Thread para ouvir mensagens
thread = threading.Thread(target=ouvir_servidor, args=(client_socket,))
thread.daemon = True
thread.start()

while True:
    mensagem = input("Digite uma mensagem (ou comandos: /lista, /privado, /sair): ")

    if mensagem.lower() == '/sair':
        client_socket.sendall(mensagem.encode('utf-8'))
        break
    client_socket.sendall(mensagem.encode('utf-8'))
client_socket.close()
print("Conexão encerrada.")
 