var socket = io(); // Função que estabelece a conexão do navegador com o servidor.

// Pergunta apelido ao entrar
var apelido = prompt("Digite seu apelido:");
socket.emit("apelido", apelido); // socket.emit() -> envia uma informação para o servidor.

// Recebe mensagens do servidor
socket.on("message", function(msg){ // socket.on() -> fica esperando um determinado evento enviado pelo servidor.
    var chat = document.getElementById("chat"); // getElementById() -> procura um elemento HTML com o ID "chat".
    chat.innerHTML += msg + "<br>"; // innerHTML -> permite acessar ou alterar o conteúdo HTML de um elemento.
    chat.scrollTop = chat.scrollHeight; // scrollTop -> posição atual da rolagem vertical.
});

// Atualiza lista de usuários conectados
socket.on("usuarios", function(lista){ // Espera o servidor enviar o evento "usuarios".
    var ul = document.getElementById("usuarios");
    ul.innerHTML = "";
    lista.forEach(function(nome){
        var li = document.createElement("li");
        li.textContent = nome;
        ul.appendChild(li); // appendChild() coloca o elemento "li" dentro do elemento "ul".
    });
});

// Função para enviar mensagem
function enviarMensagem(){
    var msg = document.getElementById("mensagem").value;
    if(msg.trim() !== ""){ // trim() -> remove espaços no início e no final do texto
        socket.emit("mensagem", msg); // Envia a mensagem para o servidor.
        document.getElementById("mensagem").value = "";
    }
}
