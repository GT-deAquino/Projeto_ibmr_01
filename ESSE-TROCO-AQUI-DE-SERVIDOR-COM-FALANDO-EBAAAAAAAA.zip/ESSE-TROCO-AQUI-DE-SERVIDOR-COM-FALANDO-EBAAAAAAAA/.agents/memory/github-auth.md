---
name: GitHub source-control authentication
description: Diagnostic lesson for GitHub connection auth while pushing project files from Replit.
---

**Rule:** Do not assume the GitHub source-control connection's “active/attached” message means `git` or `gh` can write. Verify a non-mutating operation; if a push returns an authentication error, stop and use the integration reconnect flow rather than asking for a token or putting credentials in chat.

**Why:** The connection was reported as active, but `gh` required login and HTTPS and SSH dry-run push attempts failed to authenticate. The destination repository was left unchanged.

**How to apply:** Before any GitHub push from this workspace, verify actual shell authentication. If it fails or the connection status disagrees, report that mismatch and ask the user to reconnect through Replit's GitHub integration.
